#version 120

uniform vec4 ogf_uniform_0;

void main(void) {
	gl_FragColor = gl_Color;
}

